package DatabaseLayer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author user
 */
public class Supplier {
    
    private String Supplier_ID;
    private String Supplier ;
    private String Supplier_Contact_Number;
    private String Spare_parts;

    public Supplier(String Supplier_ID, String Supplier, String Supplier_Contact_Number, String Spare_parts) {
        this.Supplier_ID = Supplier_ID;
        this.Supplier = Supplier;
        this.Supplier_Contact_Number = Supplier_Contact_Number;
        this.Spare_parts = Spare_parts;
    }
    

  
}
