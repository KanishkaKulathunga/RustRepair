/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseLayer;

/**
 *
 * @author user
 */
public class SpareParts {
    private String Supplier_ID;
    private String Spare_part_type;
    private int Quantity;
    private double Price;
    private double Total_price;

    public SpareParts(String Supplier_ID, String Spare_part_type, int Quantity, double Price, double Total_price) {
        this.Supplier_ID = Supplier_ID;
        this.Spare_part_type = Spare_part_type;
        this.Quantity = Quantity;
        this.Price = Price;
        this.Total_price = Total_price;
    }

   
    
    
}
