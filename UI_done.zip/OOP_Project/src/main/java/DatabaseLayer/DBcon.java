
package DatabaseLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class DBcon {
    
    public static Connection connect()
    {
        Connection conn=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/rust_repair","root","#Nlt");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(DBcon.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return conn;
    }
}
