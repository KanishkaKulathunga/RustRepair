/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import DatabaseLayer.DBcon;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Nimesh Lakshan
 */
public class Supplies {
    private String sparepartID;
    private String sparepartName;
    private int Quantity;
    private float price;
    private float totPrice;
    private String date;

    public Supplies()
    {
        this.sparepartID = null;
        this.sparepartName = null;
        this.Quantity = 0;
        this.price = 0f;
        this.totPrice = 0f;
        this.date = null;
    }
    
    public Supplies(String sparepartID, String sparepartName, int Quantity, float price, float totPrice, String date) {
        this.sparepartID = sparepartID;
        this.sparepartName = sparepartName;
        this.Quantity = Quantity;
        this.price = price;
        this.totPrice = totPrice;
        this.date = date;
    }

    public void addData()
    {
        Date sqlDate = Date.valueOf(this.date);
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into supplies values(?,?,?,?,?,?)");
            pr_statement.setString(1, this.sparepartID);
            pr_statement.setString(2, this.sparepartName);
            pr_statement.setInt(3, this.Quantity);
            pr_statement.setFloat(4, this.price);
            pr_statement.setFloat(5, this.totPrice);
            pr_statement.setDate(6, sqlDate);
            pr_statement.execute();
            pr_statement.close();
            JOptionPane.showMessageDialog(null, "Added");
        } catch (SQLException ex) {
            Logger.getLogger(Supplies.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void remove(String id)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from supplies where sparepartID = ?");
            pr_statement.setString(1,id);
            pr_statement.execute();
            pr_statement.close();
            JOptionPane.showMessageDialog(null, "Removed");
        } catch (SQLException ex) {
            Logger.getLogger(Supplies.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList getData(String id)
    {
        ArrayList data = new ArrayList();
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("select sparepart_name,quantity,price,tot_price,supply_date from supplies where sparepartID = ?");
            pr_statement.setString(1,id);
            ResultSet rs = pr_statement.executeQuery();
            while(rs.next())
            {
                data.add(rs.getString("sparepart_name"));
                data.add(rs.getString("quantity"));
                data.add(rs.getString("price"));
                data.add(rs.getString("tot_price"));
                data.add(rs.getString("supply_date"));
            }
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(ManageRepairs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return data;
    }
    
    public void update()
    {
        Date sqlDate = Date.valueOf(this.date);
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("update supplies "
                    + "set sparepart_name = ?,quantity = ?,price = ? ,tot_price = ?,supply_date = ?"
                    + "where sparepartID = ?");
            
            pr_statement.setString(1, this.sparepartName);
            pr_statement.setInt(2, this.Quantity);
            pr_statement.setFloat(3, this.price);
            pr_statement.setFloat(4, this.totPrice);
            pr_statement.setDate(5, sqlDate);
            pr_statement.setString(6, this.sparepartID);
            pr_statement.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Updated");
            pr_statement.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Supplies.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
