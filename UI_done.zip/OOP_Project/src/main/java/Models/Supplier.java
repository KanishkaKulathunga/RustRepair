/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import DatabaseLayer.DBcon;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Nimesh Lakshan
 */
public class Supplier {
    private String supplierID;
    private String suppliername;
    private String telephone;
    private String sparepart;
    private String date;

    public Supplier()
    {
        this.supplierID = null;
        this.suppliername = null;
        this.telephone = null;
        this.sparepart = null;
        this.date = null;
    }
    
    public Supplier(String supplierID, String suppliername, String telephone, String sparepart, String date) {
        this.supplierID = supplierID;
        this.suppliername = suppliername;
        this.telephone = telephone;
        this.sparepart = sparepart;
        this.date = date;
    }

    
    

    public void addData()
    {
        Date sqlDate = Date.valueOf(this.date);
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into supplier values(?,?,?,?,?)");
            pr_statement.setString(1, this.supplierID);
            pr_statement.setString(2, this.suppliername);
            pr_statement.setString(3, this.telephone);
            pr_statement.setString(4, this.sparepart);
            pr_statement.setDate(5, sqlDate);
            pr_statement.execute();
            
            JOptionPane.showMessageDialog(null, "Added");
            
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Supplies.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void remove(String id)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from supplier where SID = ?");
            pr_statement.setString(1, id);
            pr_statement.execute();
            JOptionPane.showMessageDialog(null, "Removed");
            pr_statement.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Supplier.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList getData(String id)
    {
        ArrayList data = new ArrayList();
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("select Supplier,ContactNo,Spare_parts,SDate from supplier where SID = ?");
            pr_statement.setString(1,id);
            ResultSet rs = pr_statement.executeQuery();
            while(rs.next())
            {
                data.add(rs.getString("Supplier"));
                data.add(rs.getString("ContactNo"));
                data.add(rs.getString("Spare_parts"));
                data.add(rs.getString("SDate"));
            }
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(ManageRepairs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return data;
    }
    
    public void update()
    {
        Date sqlDate = Date.valueOf(this.date);
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("update supplier "
                    + "set Supplier = ?,ContactNo = ?,Spare_parts = ? ,SDate = ?"
                    + "where SID = ?");
            
            pr_statement.setString(1,this.suppliername);
            pr_statement.setString(2, this.telephone);
            pr_statement.setString(3, this.sparepart);
            pr_statement.setDate(4, sqlDate);
            pr_statement.setString(5, this.supplierID);
            pr_statement.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Updated");
            pr_statement.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Supplies.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
