
package Models;

import DatabaseLayer.DBcon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Allocation {
    String job_id;
    String nic;
    
    public Allocation()
    {
        this.job_id = null;
        this.nic = null;
    }

    public Allocation(String job_id, String nic) {
        this.job_id = job_id;
        this.nic = nic;
    }
    
    public void addData()
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into workAllocation values(?,?)");
            pr_statement.setString(1, this.job_id);
            pr_statement.setString(2, this.nic);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Allocation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void remove(String id)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from workallocation where Job_ID = ?");
            pr_statement.setString(1, id);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Allocation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void removeByNIC(String nic)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from workallocation where NIC = ?");
            pr_statement.setString(1, nic);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Allocation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
