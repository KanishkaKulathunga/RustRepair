/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import DatabaseLayer.DBcon;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nimesh Lakshan
 */
public class Manager {
    private String name;
    private String dob;
    private String email;
    private String id;
    private String password;
    private String NIC;

    public Manager(String name, String dob, String email, String id, String password,String NIC) {
        this.name = name;
        this.dob = dob;
        this.email = email;
        this.id = id;
        this.password = password;
        this.NIC = NIC;
    }
    
    public void addRow()
    {
        Connection connection=DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into manager values(?,?,?,?,?,?)");
            pr_statement.setString(1, this.id);
            pr_statement.setString(2, this.name);
            pr_statement.setString(3, this.NIC);
            pr_statement.setString(4, this.dob);
            pr_statement.setString(5, this.email);
            pr_statement.setString(6, this.password);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
