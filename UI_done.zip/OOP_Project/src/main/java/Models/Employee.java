package Models;

import DatabaseLayer.DBcon;
import FrontEnd.AddEmployee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class Employee {
    private String name;
    private String nic;
    private float salary;
    
    public Employee()
    {
        this.name = null;
        this.nic = null;
        this.salary = 0f;
    }

    public Employee(String name, String nic, float salary) {
        this.name = name;
        this.nic = nic;
        this.salary = salary;
    }
    
    public void addData()
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into employee(Name,NIC,Salary) values(?,?,?)");
            pr_statement.setString(1, this.name);
            pr_statement.setString(2, this.nic);
            pr_statement.setFloat(3, this.salary);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(AddEmployee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void changeStatus(String nic)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement1 = connection.prepareStatement("select Availability from employee where NIC = ?");
            pr_statement1.setString(1, nic);
            ResultSet rs = pr_statement1.executeQuery();
            
            String state="";
            while(rs.next())
            {
                state = rs.getString("Availability");
                if(state.equals("Yes"))
                {
                    state = "No";
                }
                else
                {
                    state = "Yes";
                }
            }
            pr_statement1.close();
            
            PreparedStatement pr_statement2 = connection.prepareStatement("update employee set Availability = ? where NIC = ?");
            pr_statement2.setString(1, state);
            pr_statement2.setString(2, nic);
            pr_statement2.executeUpdate();
            pr_statement2.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void makeAvailable(String id)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("select NIC from workallocation where Job_ID = ?");
            pr_statement.setString(1, id);
            ResultSet rs = pr_statement.executeQuery();
            while(rs.next())
            {
                new Employee().changeStatus(rs.getString("NIC"));
            }
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void remove(String nic)
    {
        Connection connection = DBcon.connect();
        
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from employee where NIC = ?");
            pr_statement.setString(1, nic);
            pr_statement.execute();
            pr_statement.close();
            JOptionPane.showMessageDialog(null, "Removed");
        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
            
}
