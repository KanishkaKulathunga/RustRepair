/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import DatabaseLayer.DBcon;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ManageRepairs {

    private String id;
    private String name;
    private String address;
    private String vehicleModel;
    private String vehicleNO;
    private String arrivalDate;
    private String departureDate;
    private String telephone;
    private float price;
    
    public ManageRepairs()
    {
        this.id = null;
        this.name = null;
        this.address = null;
        this.vehicleModel = null;
        this.vehicleNO = null;
        this.arrivalDate = null;
        this.departureDate = null;
        this.telephone = null;
        this.price = 0f;
    }

    public ManageRepairs(String id, String name, String address, String vehicleModel, String vehicleNO, String arrivalDate, String departureDate, String telephone, float price) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.vehicleModel = vehicleModel;
        this.vehicleNO = vehicleNO;
        this.arrivalDate = arrivalDate;
        this.departureDate = departureDate;
        this.telephone = telephone;
        this.price = price;
    }
    
    
    public void addRow() {
        Date aDate = Date.valueOf(this.arrivalDate);
        Date dDate = Date.valueOf(this.departureDate);
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("insert into jobs values(?,?,?,?,?,?,?,?,?)");
            pr_statement.setString(1, this.id);
            pr_statement.setString(2, this.name);
            pr_statement.setString(3, this.address);
            pr_statement.setString(4, this.vehicleModel);
            pr_statement.setString(5, this.vehicleNO);
            pr_statement.setDate(6, aDate);
            pr_statement.setDate(7, dDate);
            pr_statement.setString(8, this.telephone);
            pr_statement.setFloat(9, this.price);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList getData(String id)
    {
        ArrayList data = new ArrayList();
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("select Name,Address,Vehicle_Model,Vehicle_Number,Arrival_Date,Depature_Date,Telephone,Price from jobs where ID = ?");
            pr_statement.setString(1,id);
            ResultSet rs = pr_statement.executeQuery();
            while(rs.next())
            {
                data.add(rs.getString("Name"));
                data.add(rs.getString("Address"));
                data.add(rs.getString("Vehicle_Model"));
                data.add(rs.getString("Vehicle_Number"));
                data.add(rs.getString("Arrival_Date"));
                data.add(rs.getString("Depature_Date"));
                data.add(rs.getString("Telephone"));
                data.add(rs.getFloat("Price"));
            }
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(ManageRepairs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return data;
    }
    
    public void update()
    {
        Date aDate = Date.valueOf(this.arrivalDate);
        Date dDate = Date.valueOf(this.departureDate);
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("update jobs set Name = ? ,Address = ?, Vehicle_Model = ?, Vehicle_Number = ?,"
                    + "Arrival_Date = ? , Depature_Date = ? ,Telephone = ?, Price = ?"
                    + "where ID = ?");
            
            pr_statement.setString(1, this.name);
            pr_statement.setString(2, this.address);
            pr_statement.setString(3, this.vehicleModel);
            pr_statement.setString(4, this.vehicleNO);
            pr_statement.setDate(5, aDate);
            pr_statement.setDate(6, dDate);
            pr_statement.setString(7, this.telephone);
            pr_statement.setFloat(8, this.price);
            pr_statement.setString(9, this.id);
            pr_statement.executeUpdate();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(ManageRepairs.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void remove(String id)
    {
        Connection connection = DBcon.connect();
        try {
            PreparedStatement pr_statement = connection.prepareStatement("delete from jobs where ID = ?");
            pr_statement.setString(1, id);
            pr_statement.execute();
            pr_statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(ManageRepairs.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
