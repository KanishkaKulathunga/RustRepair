/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Acer
 */
public class ManageRepair {
    private String name;
    private String id;
    private String address;
    private String phoneNo;
    private String vehiclemodel;
    private String vehiclenum;
    private String repairtype;
    private String arrivaldate;
    private String departuredate;
    private double amount;

    public ManageRepair(String name, String id, String address, String phoneNo, String vehiclemodel, String vehiclenum, String repairtype, String arrivaldate, String departuredate, double amount) {
        this.name = name;
        this.id = id;
        this.address = address;
        this.phoneNo = phoneNo;
        this.vehiclemodel = vehiclemodel;
        this.vehiclenum = vehiclenum;
        this.repairtype = repairtype;
        this.arrivaldate = arrivaldate;
        this.departuredate = departuredate;
        this.amount = amount;
    }
   
}