
package Models;

import DatabaseLayer.DBcon;
import com.sun.tools.javac.Main;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CreateID {
    public String generate(String role)
    {
        Connection connection=DBcon.connect();
        ArrayList<Integer> id_arr = new ArrayList<Integer>();
        String ID,type;
        try {
            Statement statement = connection.createStatement();
            String sqlcode;
            if(role.equals("Manager"))
            {
                sqlcode = "select empID from manager";
                type = "M";
            }
            else
            {
                sqlcode = "select empID from receptionist";
                type = "R";
            }
            ResultSet rs = statement.executeQuery(sqlcode);
            
            while(rs.next())
            {
                int val = Integer.parseInt(rs.getString("empID").substring(1));
                id_arr.add(val);
            }
            if(id_arr.isEmpty())
            {
                ID = type+"001";
            }
            else
            {
                
                int max = id_arr.get(0);
                for(int i=0;i<id_arr.size();i++)
                {
                    if(max<id_arr.get(i))
                    {
                        max = id_arr.get(i);
                    }
                }
                
                int intpart = max + 1;
                String str_intpart = ""+intpart;
                
                while(str_intpart.length()<3)
                {
                    str_intpart = "0"+str_intpart;
                }
                
                ID = type+str_intpart;
                
            }
            
            return ID;
            
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
}
